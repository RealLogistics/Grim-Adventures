Grim Adventures


A dark fantasy real-time RPG adventure — explore, battle, level up, and survive endless horrors.
Features
50×50 Massive Dark Fantasy World

Dynamic Weather (Mist, Rain, Thunderstorms)

Rare World Events (Ancient Shrines, Portals, Cursed Treasures)

Three Playable Classes (Knight, Mage, Rogue)

Skill Tree Unlocks (Power Strike, Necromancy, Rain of Arrows)

Save/Load System

Boss Battles in world corners + center

Endless Replayability (New Game+)

Hero Portraits and Custom Character Creation

Full Sound FX (Explore, Fight, Rest, Boss, Weather)

Real-Time Multiplayer Support (Work in Progress)

Screenshots


(Add images here later!)

Installation (Single Player)
Download or clone the repository.

Open index.html in any modern browser (Chrome, Firefox, Edge).

Play immediately — no installation needed.

Installation (Multiplayer - Work In Progress)


Multiplayer mode uses Node.js and Socket.IO.



Requirements:
Node.js and npm installed.

MORE TO COME...
